
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class ListFile {
	public static void main( String[] args ) throws IOException, NumberFormatException, InterruptedException {
		if (args.length !=8) {
			System.out.println("Usage: Java -jar ListFiles.jar sourcePath targetPath batchSize archiveBaseName hadoopHarPath "
					+ "metadataFilePathWithName logFilePathWithName time");
			System.exit(-1);
		}
		nioRun(args[0],args[1], Long.valueOf(args[2]).longValue(),args[3],args[4],args[5],args[6],args[7]);
	}

	private static void nioRun( String sourcefilePath, String targetPath, long maxFiles,String archiveBaseName, 
			String hadoopHarPath, String metadataFilePathWithName, String logFilePathWithName, String time)
					throws IOException, InterruptedException {

		int i = 0;
		long start = System.currentTimeMillis();
		Path sourcedir = FileSystems.getDefault().getPath(sourcefilePath);
		Path targetdir = FileSystems.getDefault().getPath(targetPath+"/"+archiveBaseName+"_"+time);

		if (!Files.exists(targetdir)) {
			Files.createDirectories(targetdir);
		}


		FileWriter fw = new FileWriter(metadataFilePathWithName+"_"+time, true);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter inner = new PrintWriter(bw);

		DirectoryStream<Path> stream = Files.newDirectoryStream(sourcedir);

		for (Path path : stream) {
			BasicFileAttributes attr  = Files.readAttributes(path, BasicFileAttributes.class);
			inner.println(path.getFileName()+"|"+attr.size()+"|"+attr.creationTime()+"|"+attr.lastModifiedTime()+
					"|"+attr.lastAccessTime()+"|"+hadoopHarPath+"/"+targetdir.getFileName()+".har/"+path.getFileName());

			Path dest = new File(targetdir.toFile().getAbsolutePath(),path.getFileName().toString()).toPath();
			Files.move(path, dest);
			if (++i == maxFiles) break;
		}
		inner.close();
		stream.close();

		long end = System.currentTimeMillis();
		long total = end-start;
		try {
			FileWriter fw_outer = new FileWriter(logFilePathWithName+"_"+time, true);
			BufferedWriter bw_outer = new BufferedWriter(fw_outer);
			PrintWriter outer = new PrintWriter(bw_outer);
			outer.println("Completed moving "+i+" files in "+total+" milliseconds");
			outer.close();
		} catch (IOException e) {
			System.out.println(e);
		}

	}
}
